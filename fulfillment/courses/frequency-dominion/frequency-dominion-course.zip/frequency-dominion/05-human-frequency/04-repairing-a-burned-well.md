# Lesson 05.04 — Repairing a burned well

**Module 05: Human Frequency** · 8 minutes · ID `m5l4`

## Outcome
If you already spammed, this is the apology that can reopen a door.

## Lesson
Own it in one line. No excuses. Offer a single relevant track and permission to ignore. Then wait 90 days. Dominion includes knowing when you are not welcome yet.

## Drill (same day)
If you have a burned contact, write the apology. Send only if it is true.
