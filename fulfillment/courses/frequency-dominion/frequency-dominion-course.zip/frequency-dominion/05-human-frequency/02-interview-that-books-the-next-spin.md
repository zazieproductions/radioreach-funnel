# Lesson 05.02 — Interview that books the next spin

**Module 05: Human Frequency** · 11 minutes · ID `m5l2`

## Outcome
Give radio a story, not a discography.

## Lesson
Hosts need tape. Give them: origin of the song in one anecdote, a local tie, a listener call-to-action, and a clean 15-second pull-quote. End by asking what they need from you next month. You are auditioning for a recurring slot, not a one-night stand.

## Drill (same day)
Write 5 interview answers under 40 seconds each.
