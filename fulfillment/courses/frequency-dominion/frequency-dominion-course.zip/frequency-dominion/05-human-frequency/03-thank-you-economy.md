# Lesson 05.03 — Thank-you economy

**Module 05: Human Frequency** · 7 minutes · ID `m5l3`

## Outcome
Make champions feel seen so they stay champions.

## Lesson
Same-day thank you. Social tag if they allow it. Physical note if they added you. Never demand a playlist screenshot in public. Protect their reputation and they will protect your song.

## Drill (same day)
Prepare a thank-you note template and a social post that credits the station first.
