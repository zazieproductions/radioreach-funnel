# Module 05 — Human Frequency

Calls, interviews, and relationships that survive one song.

1. When to pick up the phone (8 min)
2. Interview that books the next spin (11 min)
3. Thank-you economy (7 min)
4. Repairing a burned well (8 min)
