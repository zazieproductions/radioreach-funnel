# Lesson 05.01 — When to pick up the phone

**Module 05: Human Frequency** · 8 minutes · ID `m5l1`

## Outcome
Call only after a warm email or a local show hook.

## Lesson
Cold calls to music directors are how legends get you labeled a pest. Call when: they replied, you have a local date, or community radio publishes a request line. Script: 20 seconds. Name, one song, one ask, permission to send. Then shut up.

## Drill (same day)
Record yourself doing the 20-second call. Cringe means it is honest. Do it anyway.
