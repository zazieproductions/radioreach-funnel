# WB03 — 90-Word Pitch Builder

Six blocks. One ask. Under 90 words.

1. **Name** (not “Hi there”)
2. **Why this show this week**
3. **One-sentence song**
4. **Runtime + one proof line**
5. **One streaming or file link**
6. **One ask:** spin / interview / feedback (never all three)

Draft:

Word count: _____ / 90

Read out loud. Cut until it fits a kettle boil.
