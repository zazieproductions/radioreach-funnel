# WB05 — Proof Ledger

If it is not written, the next pitch starts at zero.

| Date | Station / show | Contact | Result (add / interview / no) | Quote / URL | Used in next pitch? |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |

90-day review date: __________
Sends: _____  Replies: _____  Adds: _____  Interviews: _____  Burned: _____
Kill formats under 2% reply after 40 sends.
