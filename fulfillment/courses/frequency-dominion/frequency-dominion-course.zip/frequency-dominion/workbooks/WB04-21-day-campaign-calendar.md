# WB04 — 21-Day Campaign Calendar

Release / add-week target date: __________

| Day | Date | Job | Done |
| --- | --- | --- | --- |
| W0 |  | Vault filter, scores, pitch frozen, 4×45-min blocks booked |  |
| 1 |  | Send 10 A-list |  |
| 2 |  | Log + asset check |  |
| 3 |  | Send 10 A-list |  |
| 4–7 |  | Listen / log / no panic |  |
| 8–10 |  | Touch 2 (new info + 30s clip) |  |
| 11–13 |  | Interviews / replies only |  |
| 14 |  | Touch 3 (new info only) |  |
| 15–18 |  | Confirm adds, thank-yous |  |
| 19–21 |  | Proof screenshots, market-two list of 15 |  |

T-28 skeleton for next release: war room T-28 · sends T-21 · follow-ups T-14 & T-7 · thanks T+2.
