# WB01 — Identity Sentence Worksheet

**Outcome:** One line a music director can use to file you.

Formula:

> I am the **[genre]** artist **[city / region]** stations use when they need **[specific listener feeling or show job]**.

Bad (generic): “I’m an independent singer-songwriter chasing my dreams.”
Good: “I am the alt-country artist Asheville community stations use when they need a 2:58 night-drive local with a live date this month.”

Write 5 drafts. Circle one. Insult-test: if it could fit any artist, rewrite.

1.
2.
3.
4.
5.

**Pinned sentence:**

_______________________________________________

Do not pitch until this is pinned.
