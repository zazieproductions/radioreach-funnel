# FREQUENCY DOMINION
## The 21-Day Radio Campaign Operating System
### RadioReach · radioreach.us

**This is not a vibe. This is a calendar.**

The Radio Reach Vault is 18,000+ contacts. Frequency Dominion is what you do with them so the list does not become a graveyard.

### How to use this zip

1. Read this file.
2. Print `workbooks/WB02-20-station-war-room.md` and `workbooks/WB04-21-day-campaign-calendar.md`.
3. Complete **Module 01** before you send a single email.
4. Load **20 stations**, not 2,000.
5. Run Days 1–21 from Module 04. Log every send.
6. Compound proof in Module 06. Repeat for the next city.

Classroom (progress + notes): `https://radioreach.us/#/course/classroom`

### Folder map

| Folder | Contents |
| --- | --- |
| `01`–`06` | 24 lesson scripts with outcomes, drills, templates |
| `workbooks/` | 5 printable worksheets |
| `swipe-file/` | Subject lines, 90-word pitch, 3-touch, call script, thank-you |
| `sequences/` | Buyer email + SMS copy (operator / self-nurture) |

### Rules that keep this legal and useful

- Targeted, named, human outreach only. No BCC markets. No “Hi there.”
- You are responsible for CAN-SPAM, GDPR, CASL, and station policies.
- Airplay is not guaranteed. This is a campaign OS, not a spin machine.
- Educational templates are not legal advice.

© 2026 RadioReach. All rights reserved. Licensed to the original purchaser for personal campaign use. Do not resell or redistribute this zip.
