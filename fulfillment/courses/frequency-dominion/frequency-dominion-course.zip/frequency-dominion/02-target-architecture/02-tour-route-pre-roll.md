# Lesson 02.02 — Tour-route pre-roll

**Module 02: Target Architecture** · 12 minutes · ID `m2l2`

## Outcome
Time pitches 21 days before every date on the calendar.

## Lesson
A show without radio is a secret. Radio without a show is a rumor. Stack them. For each tour city, pull stations 21 days out. Subject line references the venue and date. Body offers an interview window the afternoon of load-in. This is how regional acts look national before they are.

## Template

```
City | Date | Station | Contact | Send day (D-21) | Interview offer | Follow-up D-10 | Follow-up D-3
```

## Drill (same day)
If you have no tour, invent a 4-city weekend run and build the 21-day calendar anyway.
