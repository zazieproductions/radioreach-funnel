# Lesson 02.04 — The 20-station war room

**Module 02: Target Architecture** · 8 minutes · ID `m2l4`

## Outcome
Lock a 21-day list you can actually work.

## Lesson
Twenty stations. Not two hundred. Dominion is concentration. Print the list. Put it on the wall. Each name gets a status: queued, sent, opened, replied, added, dead. You update it daily like a chart. If you cannot manage twenty, you cannot manage a career.

## Drill (same day)
Create the war-room table. Share it with one accountability human.
