# Lesson 02.03 — Format fit scoring

**Module 02: Target Architecture** · 10 minutes · ID `m2l3`

## Outcome
Score every station 0–5 so you stop wasting A-game emails on D-fit rooms.

## Lesson
Score: genre match (0–2), locality (0–1), named human (0–1), recent independent adds (0–1). Total 4–5 = send this week. 2–3 = nurture list. 0–1 = do not touch. Volume without scoring is how you train yourself that radio doesn't work.

## Drill (same day)
Score your 25 hometown contacts. Only 4–5s get Lesson 3.1 scripts.
