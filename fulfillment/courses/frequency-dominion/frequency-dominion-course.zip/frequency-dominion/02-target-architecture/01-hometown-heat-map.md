# Lesson 02.01 — Hometown heat map

**Module 02: Target Architecture** · 14 minutes · ID `m2l1`

## Outcome
Extract every relevant station within 90 minutes of home.

## Lesson
Open the RadioReach Vault. Filter your metro, then adjacent cities on your commute. Highlight music directors and specialty hosts first, then program directors, then general station lines last. Hometown is not cute. Hometown is the only market where you are not a stranger. Directors champion locals because locals make the station feel planted. You start here or you start cold.

## Drill (same day)
Export 25 hometown contacts. Rank A/B/C by format fit. A-list gets personalized audio this week.
