# Module 02 — Target Architecture

Build a city-by-city ladder so every send has a reason.

1. Hometown heat map (14 min)
2. Tour-route pre-roll (12 min)
3. Format fit scoring (10 min)
4. The 20-station war room (8 min)
