# Lesson 03.02 — The 90-word pitch

**Module 03: The Pitch Weapon** · 16 minutes · ID `m3l2`

## Outcome
Write a pitch a director can finish before the kettle boils.

## Lesson
Structure: (1) their name, (2) why this show this week, (3) one-sentence song, (4) runtime and one proof line, (5) one streaming link, (6) one ask (spin, interview, or feedback — never all three). Ninety words. If you cannot say it in ninety, you do not know what the song is for.

## Drill (same day)
Write the 90-word pitch. Read it out loud. Cut until it is under 90.
