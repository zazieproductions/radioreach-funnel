# Lesson 03.03 — EPK that does not embarrass you

**Module 03: The Pitch Weapon** · 11 minutes · ID `m3l3`

## Outcome
One page: photo, bio 80 words, links, one-sheet facts.

## Lesson
Directors do not want your life story. They want: who, where, what it sounds like, where to play it, who already did. One page PDF or a clean link. No WeTransfer dumps. No 14-page press kits. Cover art that does not look like a default font. If the art is weak, fix art before you scale sends.

## Drill (same day)
Build the one-pager. Have a civilian read it in 20 seconds and tell you the genre.
