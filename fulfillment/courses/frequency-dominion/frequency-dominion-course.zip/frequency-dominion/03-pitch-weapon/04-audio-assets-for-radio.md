# Lesson 03.04 — Audio assets for radio

**Module 03: The Pitch Weapon** · 10 minutes · ID `m3l4`

## Outcome
Deliver radio-ready files, not a Bandcamp shrug.

## Lesson
WAV or high-bitrate MP3, clean metadata, no 2 minutes of silence, no unmastered bounce named finalFINAL3. Include a 30-second hook clip for imaging. Label files: Artist_Song_RadioEdit. If you cannot be found in a folder, you will not be found on the clock.

## Drill (same day)
Export radio edit + 30s clip with correct metadata today.
