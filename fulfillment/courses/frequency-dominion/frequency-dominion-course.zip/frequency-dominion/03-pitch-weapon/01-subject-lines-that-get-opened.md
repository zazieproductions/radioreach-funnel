# Lesson 03.01 — Subject lines that get opened

**Module 03: The Pitch Weapon** · 13 minutes · ID `m3l1`

## Outcome
Build 11 subject lines from the local-artist swipe logic.

## Lesson
Subject lines that die: New single for your consideration. Subject lines that live: Local [genre] for [show name] — 2:58, [city] date [month]. Specificity is respect. You prove you know the show. You prove the clock. You prove you are not a blast. Write eleven. Kill eight. Keep three. A/B them across your A-list only.

## Template

```
1. [City] [genre] for [show] — [runtime]
2. Interview window [date] + track
3. Follow-up: still a fit for [show]?
```

## Drill (same day)
Write 11. Circle 3. Never reuse a loser on the same contact.
