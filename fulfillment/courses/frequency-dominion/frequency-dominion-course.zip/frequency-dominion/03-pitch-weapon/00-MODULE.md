# Module 03 — The Pitch Weapon

Emails that survive 1.4 seconds of a music director's thumb.

1. Subject lines that get opened (13 min)
2. The 90-word pitch (16 min)
3. EPK that does not embarrass you (11 min)
4. Audio assets for radio (10 min)
