# Lesson 04.01 — Week 0: load the war room

**Module 04: The 21-Day Campaign** · 9 minutes · ID `m4l1`

## Outcome
Contacts scored, assets ready, send blocks booked.

## Lesson
Before day 1 you do not send. You load. Vault filtered. Scores done. Pitch frozen. Calendar blocks: 45 minutes, four days a week. Campaigns fail in the gaps between I'll do it later. Dominion is a calendar object.

## Drill (same day)
Put four 45-minute blocks on the next 21 days. Non-negotiable.
