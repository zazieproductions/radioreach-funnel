# Module 04 — The 21-Day Campaign

A calendar that tells you who to email on which day.

1. Week 0: load the war room (9 min)
2. Days 1–7: first blood sends (12 min)
3. Days 8–14: the 3-touch follow-up (12 min)
4. Days 15–21: adds, interviews, next market (10 min)
