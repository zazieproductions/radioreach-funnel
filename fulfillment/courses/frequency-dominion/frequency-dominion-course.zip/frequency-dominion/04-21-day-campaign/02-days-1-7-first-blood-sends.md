# Lesson 04.02 — Days 1–7: first blood sends

**Module 04: The 21-Day Campaign** · 12 minutes · ID `m4l2`

## Outcome
Send 20 A-list emails. Log every one.

## Lesson
Ten on day 1, ten on day 3. Personal first lines only. Log station, name, subject, time. If you cannot log it, it did not happen. Expect silence. Silence is data, not rejection. You are buying the right to follow up.

## Drill (same day)
Send 10 today. Screenshot the log.
