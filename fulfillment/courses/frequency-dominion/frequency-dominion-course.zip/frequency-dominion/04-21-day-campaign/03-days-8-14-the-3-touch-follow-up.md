# Lesson 04.03 — Days 8–14: the 3-touch follow-up

**Module 04: The 21-Day Campaign** · 12 minutes · ID `m4l3`

## Outcome
Run the cadence that doubled replies.

## Lesson
Touch 2 (day 8–10): one sentence + the 30s clip. Touch 3 (day 14): new information only — a show date, a quote, a different edit. Never just bumping this. Never guilt. If they say no, thank them and leave the door unburned.

## Template

```
Touch 2: [Name] — 30s hook if easier: [link]. Still a fit for [show]?
Touch 3: New: [show date / quote / edit]. Happy to drop it if not a fit.
```

## Drill (same day)
Write Touch 2 and Touch 3 now so you are not improvising under anxiety.
