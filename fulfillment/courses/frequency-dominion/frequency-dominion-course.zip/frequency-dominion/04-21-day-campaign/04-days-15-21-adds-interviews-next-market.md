# Lesson 04.04 — Days 15–21: adds, interviews, next market

**Module 04: The 21-Day Campaign** · 10 minutes · ID `m4l4`

## Outcome
Convert replies into calendar facts and climb the ladder.

## Lesson
A reply is not a win until it is a spin, an interview, or a clear no. Confirm add dates. Send thank-you same day. Screenshot the spin if it airs. That screenshot becomes proof for Module 1's next cycle and for the next city on the ladder. Then clone the war room for market two.

## Drill (same day)
Draft the thank-you. Draft the market-two list of 15 stations.
