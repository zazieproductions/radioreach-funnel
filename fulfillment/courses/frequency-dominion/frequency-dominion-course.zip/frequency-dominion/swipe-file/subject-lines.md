# Subject lines that live (and die)

**Die:** New single for your consideration · Demo attached · Checking in · Unsigned artist seeking airplay

**Live (fill the brackets):**

1. [City] [genre] for [show] — [runtime]
2. Interview window [date] + [song]
3. Local date [venue] [month] — radio edit [runtime]
4. Follow-up: still a fit for [show]?
5. 30s hook for [daypart] — [Artist]
6. [Station] specialty: [song] (college add last week: [station])
7. Load-in [city] [date] — live + radio edit
8. Replacement copy if last link broke — [song]
9. [Name] — one track, one ask
10. Hometown [genre] for this week’s [show]
11. New info only: [quote or edit] + [song]

Write 11. Kill 8. Keep 3. Never reuse a loser on the same contact.
