# 90-word pitch (swipe)

Hi [Name] —

I listen to [show] for [specific reason]. This week I’m offering [Song], a [runtime] [genre] record built for [daypart / localism]. I’m the [identity sentence]. Proof: [one line]. Stream / radio edit: [one link].

Ask (pick one): Would you consider a spin on [show] this month? / I can do a 10-minute phoner [day] before load-in. / If it’s not a fit, a one-line no is enough.

Thanks,
[Artist]
[City] · [phone]

---

Touch 2: [Name] — 30s hook if easier: [link]. Still a fit for [show]?

Touch 3: New: [show date / quote / edit]. Happy to drop it if not a fit.
