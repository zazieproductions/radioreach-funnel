# Call · interview · thank-you

## 20-second call (only after reply, local date, or published request line)

“Hi [Name], this is [Artist] in [city]. I emailed about [Song], [runtime]. One ask: may I send the radio edit for [show], or is email better? I’ll keep it to one track.”

Then shut up.

## Interview: 5 answers under 40 seconds

1. Origin of the song (one anecdote).
2. Local tie.
3. What it sounds like (no novel).
4. Listener CTA (show / stream / call-in).
5. 15-second pull-quote for imaging.

End: “What do you need from me next month?”

## Thank-you

Email same day. Credit the station first on social if they allow it. Physical note if they added you. Never demand a public screenshot.

## Burned-well apology

“I blasted you before. That was disrespectful. One relevant track is here: [link]. Ignore with my blessing. I won’t follow up for 90 days.”
