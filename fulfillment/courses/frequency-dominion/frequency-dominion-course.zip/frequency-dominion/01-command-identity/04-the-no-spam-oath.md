# Lesson 01.04 — The no-spam oath

**Module 01: Command Identity** · 6 minutes · ID `m1l4`

## Outcome
Commit to targeted, named, human outreach only.

## Lesson
18,000 contacts is a weapon. Weapons require discipline. You will never BCC a market. You will never use merge fields that say Hi there. You will never send the same paragraph to college jazz and country morning drive. Break this oath and you burn the well for every independent artist behind you — including future you.

## Drill (same day)
Write the oath on paper. Screenshot it. First campaign = 20 named contacts, not 2,000.
