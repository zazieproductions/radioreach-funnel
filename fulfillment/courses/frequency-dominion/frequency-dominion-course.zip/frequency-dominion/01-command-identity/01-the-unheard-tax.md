# Lesson 01.01 — The unheard tax

**Module 01: Command Identity** · 8 minutes · ID `m1l1`

## Outcome
Name the exact cost of another ignored release cycle.

## Lesson
You do not have a talent problem. You have a distribution identity problem. Radio directors do not owe you a listen. They owe their audience a show that does not suck. Frequency Dominion starts here: you are not begging for spins. You are offering a local, genre-fit, time-stamped solution. Write one sentence: I am the [genre] artist [city] stations use when they need [specific listener feeling]. That sentence is your north star for every email, voicemail, and follow-up in this course.

## Drill (same day)
Write the identity sentence. Pin it above your send list. Do not pitch until it is specific enough to insult a generic artist.
