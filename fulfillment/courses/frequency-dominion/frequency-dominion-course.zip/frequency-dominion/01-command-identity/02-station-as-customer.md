# Lesson 01.02 — Station as customer

**Module 01: Command Identity** · 11 minutes · ID `m1l2`

## Outcome
Map what a music director actually buys with a spin.

## Lesson
A spin is inventory. Inventory has constraints: clock, format, legal ID, imaging, localism, and ego. Your track is a SKU. If the SKU does not fit the clock, it dies. In this lesson you list five constraints for your first target format (college, community, specialty, or commercial). You will never again send a 7-minute progressive suite to a 3:30 CHR clock and call it the industry is unfair.

## Template

```
Format: ____
Clock max: ____
Localism hook: ____
Competing current: ____
Why this week: ____
```

## Drill (same day)
Pick one format. Write five constraints. Cut or edit one song to fit the tightest clock.
