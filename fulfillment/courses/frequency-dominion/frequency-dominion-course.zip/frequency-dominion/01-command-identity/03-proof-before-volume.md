# Lesson 01.03 — Proof before volume

**Module 01: Command Identity** · 9 minutes · ID `m1l3`

## Outcome
Assemble a 4-line credibility stack that does not lie.

## Lesson
Directors delete bios. They keep proof. Proof is: local show date, previous add, playlist, press quote, or a named champion at another station. Stack four lines. If you have none, manufacture ethical proof this week: one hometown gig, one college paper, one community station interview. Dominion is earned in public, then leveraged in the inbox.

## Drill (same day)
Write a 4-line proof stack. If a line is empty, schedule the action that fills it in 7 days.
