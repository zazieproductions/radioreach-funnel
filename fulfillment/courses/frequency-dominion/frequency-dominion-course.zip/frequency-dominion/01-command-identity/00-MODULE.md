# Module 01 — Command Identity

Stop sounding like a fan. Start sounding like a station's problem-solver.

1. The unheard tax (8 min)
2. Station as customer (11 min)
3. Proof before volume (9 min)
4. The no-spam oath (6 min)
