# Lesson 06.02 — Airplay to income

**Module 06: Empire Loop** · 12 minutes · ID `m6l2`

## Outcome
Route credibility into gigs, sync, and freelance.

## Lesson
Radio is not a paycheck. Radio is a badge. Use the badge: pitch venues with now spinning on X, pitch supervisors with regional story, pitch clients with proof you understand markets. The Vault opened the door. Frequency Dominion teaches you to walk through it with a rate.

## Drill (same day)
Write one venue email and one client email that cite a specific station.
