# Module 06 — Empire Loop

Turn one add into a machine: proof, income, next release.

1. Proof compounding (9 min)
2. Airplay to income (12 min)
3. Release calendar as a radio calendar (10 min)
4. The 90-day dominion review (8 min)
