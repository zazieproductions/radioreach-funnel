# Lesson 06.01 — Proof compounding

**Module 06: Empire Loop** · 9 minutes · ID `m6l1`

## Outcome
Every add becomes a line in the next pitch.

## Lesson
Keep a proof ledger: station, date, show, quote. This is how Ohio gets Unearthed and how Unearthed gets the next coastal specialty show. Without a ledger you restart from zero every single.

## Drill (same day)
Create the ledger. Enter any past win, even a campus show.
