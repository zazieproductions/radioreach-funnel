# Lesson 06.03 — Release calendar as a radio calendar

**Module 06: Empire Loop** · 10 minutes · ID `m6l3`

## Outcome
Never drop a single without a 21-day radio plan attached.

## Lesson
Add date thinking: radio wants lead time. Work backwards from release: war room at T-28, first sends T-21, follow-ups T-14 and T-7, thank-yous T+2. If you cannot staff that, delay the drop. Amateur calendars create amateur careers.

## Drill (same day)
Map your next release onto the T-28 skeleton.
