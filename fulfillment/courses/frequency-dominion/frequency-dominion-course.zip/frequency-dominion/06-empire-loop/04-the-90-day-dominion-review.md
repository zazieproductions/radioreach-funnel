# Lesson 06.04 — The 90-day dominion review

**Module 06: Empire Loop** · 8 minutes · ID `m6l4`

## Outcome
Audit sends, replies, adds, and kill what does not convert.

## Lesson
Metrics that matter: sends, personalization rate, replies, adds, interviews, burned contacts. Vanity: total emails. Kill formats under 2% reply after 40 sends. Double down on the format that answered. This is how lists become empires.

## Drill (same day)
Schedule the 90-day review on your calendar now.
